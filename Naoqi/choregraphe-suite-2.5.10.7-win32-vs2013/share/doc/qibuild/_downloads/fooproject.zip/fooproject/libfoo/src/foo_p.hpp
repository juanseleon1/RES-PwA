#ifndef _FOO_PRIVATE_HPP_
#define _FOO_PRIVATE_HPP_


int private_method();


#endif // _FOO_PRIVATE_HPP_
